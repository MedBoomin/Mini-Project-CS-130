from flask import Flask, request, render_template, jsonify, Response
import threading
from threading import Thread
import queue
import sqlite3
import time
import math
import json
import logging
import asyncio

app = Flask(__name__, static_url_path='/static')
enqueue_count = 0
new_data = []
start_time = time.time()

# Configure logging
logging.basicConfig(level=logging.DEBUG)
app.logger.setLevel(logging.DEBUG)

# Create a queue to hold incoming requests
request_queue = queue.Queue()

# Create a connection to the SQLite database
conn = sqlite3.connect('request_log.db')
cursor = conn.cursor()

# Create a table to store processed requests
cursor.execute('''
    CREATE TABLE IF NOT EXISTS request_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        input TEXT,  -- Change data type to TEXT
        result TEXT,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
''')

# Commit and close the database connection
conn.commit()
conn.close()

first_request_timestamp = None
last_request_timestamp = None

async def process_queue():
    while True:
        if not request_queue.empty():
            data = request_queue.get()
            result = math.factorial(data)
            timestamp = time.strftime('%Y-%m-%d %H:%M:%S')

            if first_request_timestamp is None:
                first_request_timestamp = time.time()  # Record the timestamp of the first request

            try:
                # Log the processed request to the SQLite database
                db_connection = sqlite3.connect('request_log.db')
                db_cursor = db_connection.cursor()
                db_cursor.execute("INSERT INTO request_log (input, result, timestamp) VALUES (?, ?, ?)",
                                  (str(data), result, timestamp))
                db_connection.commit()
                db_cursor.close()
                db_connection.close()
                
                last_request_timestamp = time.time()
            except Exception as e:
                app.logger.error(f"Error inserting into the database: {str(e)}")

        await asyncio.sleep(0.1)


@app.route('/updates')
async def sse_updates():
    def event_stream():
        last_id = 0  # Initialize the last_id
        while True:
            conn = sqlite3.connect('request_log.db')
            cursor = conn.cursor()
            cursor.execute(f'SELECT id, input, result, timestamp FROM request_log WHERE id > {last_id} ORDER BY timestamp ASC')
            data = cursor.fetchall()
            conn.close()

            for row in data:
                event = {
                    'id': row[0],
                    'input': row[1],
                    'result': row[2],
                    'timestamp': row[3]
                }
                yield 'data: ' + json.dumps(event) + '\n\n'

            if data:
                last_id = data[-1][0]  # Update last_id

            time.sleep(1)  # Introduce a delay before checking again

    return Response(event_stream(), content_type='text/event-stream')

def run_async_loop():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(process_queue())

# Clear the database upon app startup
def clear_database():
    print("Clearing database")  # Add this line for debugging
    conn = sqlite3.connect('request_log.db')
    cursor = conn.cursor()
    cursor.execute('DELETE FROM request_log')
    conn.commit()
    conn.close()

def create_table():
    conn = sqlite3.connect('request_log.db')
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS request_log (
        id TEXT PRIMARY KEY,
        input TEXT,
        result TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )''')
    conn.commit()
    conn.close()

# Clear the request log
@app.route('/clear-log', methods=['POST'])
def clear_log():
    global first_request_timestamp  # Reset the first request timestamp
    first_request_timestamp = None
    conn = sqlite3.connect('request_log.db')
    cursor = conn.cursor()
    cursor.execute('DELETE FROM request_log')
    conn.commit()
    conn.close()
    return 'Request log cleared', 200

@app.route('/')
def index():
   return render_template('index.html', first_request_timestamp=first_request_timestamp, last_request_timestamp=last_request_timestamp)

# SQLite database connection pool
db_connection_pool = sqlite3.connect('request_log.db', check_same_thread=False)

@app.route('/hook', methods=['POST'])
def hook():
    try:
        data = request.get_json()

        if data is None:
            return 'Invalid JSON data', 400

        if 'integer' in data:
            integer = data['integer']

            # Decide whether to store as INTEGER or TEXT based on a threshold
            if integer <= 2147483647:  # SQLite maximum INTEGER value
                result = integer
            else:
                result = str(integer)

            # Open a transaction and insert data into the SQLite database
            with db_connection_pool:
                cursor = db_connection_pool.cursor()
                cursor.execute("BEGIN")  # Start a transaction
                cursor.execute("INSERT INTO request_log (input, result, timestamp) VALUES (?, ?, CURRENT_TIMESTAMP)", (integer, result))
                cursor.execute("COMMIT")  # Commit the transaction

            return 'Enqueued', 200
        else:
            return 'Missing integer field', 400
    except Exception as e:
        app.logger.error(f"Error in /hook: {str(e)}")
        return 'Internal Server Error', 500

@app.route('/log')
def log():
    # Retrieve data from the SQLite database
    with db_connection_pool:
        cursor = db_connection_pool.cursor()
        cursor.execute("SELECT input, timestamp FROM request_log ORDER BY timestamp DESC LIMIT 100")
        data = cursor.fetchall()

    return render_template('index.html', data=data)

@app.route('/clear-data', methods=['POST'])
def clear_data():
    global first_request_timestamp  # Reset the first request timestamp
    first_request_timestamp = None
    conn = sqlite3.connect('request_log.db')
    cursor = conn.cursor()
    cursor.execute('DELETE FROM request_log')
    conn.commit()
    conn.close()
    return 'Data cleared', 200

@app.route('/clear-on-refresh', methods=['GET'])
def clear_on_refresh():
    # Clear the request log
    global first_request_timestamp  # Reset the first request timestamp
    first_request_timestamp = None
    conn = sqlite3.connect('request_log.db')
    cursor = conn.cursor()
    cursor.execute('DELETE FROM request_log')
    conn.commit()
    conn.close()
 
    return 'Data cleared on page refresh', 200

@app.after_request
def add_no_cache_header(response):
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    return response

# Implement the factorial function as needed
def factorial(n):
    if n == 0:
        return 1
    return n * factorial(n - 1)

if __name__ == '__main__':
    # Create and start a thread for processing the queue
    processing_thread = Thread(target=asyncio.run, args=(process_queue(),))
    processing_thread.start()

    # Start the Flask web application
    app.run(host="0.0.0.0", port=5000, threaded=True)
