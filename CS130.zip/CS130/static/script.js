document.addEventListener("DOMContentLoaded", function () {
    const eventSource = new EventSource('/updates');
    const logData = document.getElementById('log-data');
    const clearButton = document.getElementById('clear-button');
    const queueState = document.getElementById('queue-state');
    let currentQueue = 0;

    clearButton.addEventListener('click', () => {
        fetch('/clear-log', { method: 'POST' })
            .then(response => {
                if (response.ok) {
                    console.log('Request log cleared');
                    logData.innerHTML = ''; // Clear the table on button click
                    currentQueue = 0; // Reset the queue count
                    queueState.textContent = `Queue: ${currentQueue}`; // Update the queue state
                } else {
                    console.error('Failed to clear request log');
                }
            })
            .catch(error => {
                console.error('Error while clearing request log:', error);
            });
    });

    // Set the initial queue count to 0 when the page is loaded
    currentQueue = 0;
    queueState.textContent = `Queue: ${currentQueue}`;

    eventSource.onmessage = function (event) {
        const data = JSON.parse(event.data);
        const newRow = document.createElement('tr');
        newRow.innerHTML = `
            <td>${data.id}</td>
            <td>${data.input}</td>
            <td>${data.result}</td>
            <td>${data.timestamp}</td>
        `;
        logData.appendChild(newRow);

        // Update the queue state
        currentQueue++;
        queueState.textContent = `Queue: ${currentQueue}`;
    };
});
