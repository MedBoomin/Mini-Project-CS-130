import requests
import random
import concurrent.futures

# Define the URL of your Flask application's /hook endpoint
url = 'http://127.0.0.1:5000/hook'  # Change the URL as needed

def send_request(integer):
    data = {'integer': integer}
    response = requests.post(url, json=data)

    if response.status_code == 200:
        return f"Enqueued: {integer}"
    else:
        return f"Failed to enqueue: {integer}"

# Generate 1000 random integers to simulate the requests
integers = [random.randint(1, 5000) for _ in range(5000)]

# Use ThreadPoolExecutor to send requests concurrently
with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
    results = executor.map(send_request, integers)

# Print the results
for result in results:
    print(result)
